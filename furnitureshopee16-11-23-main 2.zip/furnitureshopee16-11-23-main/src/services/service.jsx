import React from "react";
import { Container, Row,Col} from "reactstrap";

const service = () => {
  return <div>Services</div>;
};  

export default service;