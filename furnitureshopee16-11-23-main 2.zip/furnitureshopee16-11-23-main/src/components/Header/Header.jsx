import React,{useRef, useEffect} from "react";

import { NavLink, useNavigate} from "react-router-dom";

import "./Header.css";



import logo from '../../assets/images/eco-logo.png'
import userIcon from '../../assets/images/user-icon.png'

import  {Container, Row}  from "reactstrap";
import { toast } from "react-toastify";
import useAuth from "../../custom-hooks/useAuth";
import { Link } from "react-router-dom";
import { signOut } from "firebase/auth";
import { auth } from "../../firebase.config";



//Add framer motion for animation
import { motion } from "framer-motion";

const nav___links = [
    {
        path: 'home',
        display: 'Home'
    },
    {
        path: 'shop',
        display: 'shop'
    },
    {
        path: 'cart',
        display: 'cart'
    },
]
//Navigation------------------------------------------------------------------------------------

//Sticky Header------------------------------------------------------------------------------------
const Header = () => {

    const headerRef = useRef(null);
    const profileActionRef = useRef(null);
    const navigate = useNavigate();
    const {currentUser} = useAuth();

    const menuRef = useRef(null);

    const stickyHeaderFunc = () => {
        window.addEventListener('scroll', () => {
            if(document.body.scrollTop > 80 || 
                document.documentElement.scrollTop 
                > 80){
                    headerRef.current.classList.add('sticky__header')
                }else{
                    headerRef.current.classList.remove('sticky__header')
                }                  
        });
    };

    const toggleProfileAction = () => profileActionRef.current.classList.
    toggle('show__profileActions');

    useEffect(() => {
        stickyHeaderFunc()
        return () => window.removeEventListener('scroll',stickyHeaderFunc);
        
        });

        const menuToggle = ()=> menuRef.current.classList.toggle("active__menu");
        

//sticky header End-------------------------------------------------------------------------------
  return <header className="header" ref={headerRef}>
    <Container>
        <Row>
            <div className="nav_wrapper">
                <div className="logo">
                    <img src={logo} alt="logo" />
                    <div>
                        <h1>furnitureshopee</h1>
                    </div>
                </div>

                <div className="navigation" ref={menuRef} onClick={menuToggle}>             
                <ul className="menu">

                   {
                    nav___links.map((item, index) =>(
                        <li className="nav_item" key={index}>
                        <NavLink 
                        to={item.path} 
                        className={(navClass)=>
                        navClass.isActive ? 'nav__active': ""
                        }
                        >
                        {item.display}
                        </NavLink>
                    </li>
                    ))}
            
                    </ul> 
                </div> 

                   <div className="nav_icons">


                    <span className="fav_icon"><i class="ri-heart-line"></i>
                    <span className="badge">1</span>
                    </span>
                    <span className="cart_icon"><i class="ri-shopping-bag-line"></i>
                    <span className="badge">1</span>
                    </span>


                    <div className="profile"> 
                        <motion.img whileTap={{scale: 1.2}} src={ currentUser? 
                        currentUser.photoURL: userIcon} 
                        alt="" 
                        onClick={toggleProfileAction}
                        /> 


                        <div className="profile__actions" ref={profileActionRef}
                            onClick={toggleProfileAction}>
                            {
                                currentUser ? 
                                <span>Logout</span>
                                 :  <div>
                                <Link to="/Signup">Signup</Link>
                                <Link to="/Login">Login</Link>
                                    </div>
                            }
                        </div>




                        </div>
                       <div className="mobile__menu">                            
                    <span onClick={menuToggle}>
                        <i class="ri-menu-line"></i></span>
                   </div>
                   </div>

                   
            </div>
            </Row>
        </Container>
  </header>
};      

export default Header;

