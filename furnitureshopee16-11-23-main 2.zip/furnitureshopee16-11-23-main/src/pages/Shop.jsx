import react from 'react';  

const Shop = () => {
    return (
        <div>
           Shop
        </div>
    );
}
export default Shop;
