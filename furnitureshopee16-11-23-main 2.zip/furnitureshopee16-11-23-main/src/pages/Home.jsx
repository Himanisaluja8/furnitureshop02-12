import React from 'react';  
import { Link } from 'react-router-dom';

//motion for button
//import {motion} from 'react-motion';

import Helmet from '../components/Helmet/Helmet';
import "../styles/home.css";

import heroImg from '../assets/images/hero-img.png';

import { Container, Row, Col } from 'reactstrap';


const Home = () => {

    const year = new Date().getFullYear();
    return <Helmet title={"Home"}>
        <section className="hero__section">
         <Container>
            <Row>
                <Col lg={6}>
                    <div className="hero__content">
                       <p className="hero__subtitle">
                        Trending Products in {year}
                       </p>
                       <h2>More Text Here Himani </h2>
                       <p>Furniture business in Auckland Zealand, where you will find all your home décor needs.</p>

                          <button className="buy__btn"><Link to='/shop'>SEE FURNITURE</Link></button>
                    </div>
                 </Col>
                    <Col lg='6' md='6'>
                        <div className="hero__img">
                            <img src={heroImg} alt="hero" />
                        </div>
                        </Col>


            </Row>
         </Container>

        </section>
    </Helmet>;
};
export default Home;
